﻿
// See https://aka.ms/new-console-template for more information

using ProgPOE1_ST10280755_AadamNaidoo;
using RecipeApp;




using System;
using System.Collections.Generic;

namespace RecipeApp
{
    // Main class to handle user input and interaction
    public class MainClass
    {
        public static void Main(string[] args)
        {
            // Create a new RecipeManager instance
            RecipeManager recipeManager = new RecipeManager();

            // Loop for user interaction
            while (true)
            {
                Console.WriteLine("\nWhat would you like to do?");
                Console.WriteLine("1. Enter a new recipe");
                Console.WriteLine("2. Scale the recipe");
                Console.WriteLine("3. Reset quantities to original values");
                Console.WriteLine("4. Clear all data to enter a new recipe");
                Console.WriteLine("5. Exit");

                // Read user choice
                Console.Write("Enter your choice: ");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        recipeManager.EnterNewRecipe();
                        break;
                    case 2:
                        recipeManager.ScaleRecipe();
                        break;
                    case 3:
                        recipeManager.ResetQuantities();
                        break;
                    case 4:
                        recipeManager.ClearData();
                        break;
                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 5.");
                        break;
                }
            }
        }
    }

    // Class to manage recipe-related operations
    internal class RecipeManager
    {
        private Recipe currentRecipe;

        // Method to enter a new recipe
        internal void EnterNewRecipe()
        {
            Console.WriteLine("Enter recipe details:");
            Console.Write("Recipe Name: ");
            string name = Console.ReadLine();
            Console.Write("Number of Ingredients: ");
            int numIngredients = int.Parse(Console.ReadLine());
            Console.Write("Number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());

            currentRecipe = new Recipe(name, numIngredients, numSteps);

            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine("Enter details for Ingredient " + (i + 1) + ":");
                Console.Write("Name: ");
                string ingredientName = Console.ReadLine();
                Console.Write("Quantity: ");
                double quantity = double.Parse(Console.ReadLine());
                Console.Write("Unit of measurement: ");
                string unit = Console.ReadLine();

                currentRecipe.AddIngredient(ingredientName, quantity, unit);
            }

            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine("Enter details for step " + (i + 1) + ":");
                Console.Write("Description: ");
                string stepDescription = Console.ReadLine();

                currentRecipe.AddStep(stepDescription);
            }

            Console.WriteLine("\nRecipe entered successfully!");
        }

        // Method to scale the recipe
        internal void ScaleRecipe()
        {
            if (currentRecipe == null)
            {
                Console.WriteLine("No recipe entered yet. Please enter a recipe first.");
                return;
            }

            Console.Write("Enter scaling factor (0.5 for half, 2 for double, 3 for triple): ");
            double factor = double.Parse(Console.ReadLine());

            currentRecipe.ScaleIngredients(factor);
            Console.WriteLine("Recipe scaled successfully!");
            currentRecipe.PrintRecipe();
        }

        // Method to reset ingredient quantities to original values
        internal void ResetQuantities()
        {
            if (currentRecipe == null)
            {
                Console.WriteLine("No recipe entered yet. Please enter a recipe first.");
                return;
            }

            currentRecipe.ResetQuantities();
            Console.WriteLine("Ingredient quantities reset to original values.");
            currentRecipe.PrintRecipe();
        }

        // Method to clear all data
        internal void ClearData()
        {
            currentRecipe = null;
            Console.WriteLine("All data cleared. Enter a new recipe to continue.");
        }
    }

    


}

