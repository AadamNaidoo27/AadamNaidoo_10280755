﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgPOE1_ST10280755_AadamNaidoo
{
    // Class to represent a Recipe
    internal class Recipe
    {
        private string Name;
        private List<Ingredients> ingredientList;
        private List<string> stepsList;

        // Constructor to initialize a Recipe instance
        public Recipe(string name, int numIngredients, int numSteps)
        {
            Name = name;
            ingredientList = new List<Ingredients>();
            stepsList = new List<string>();
        }

        // Method to add an ingredient to the recipe
        internal void AddIngredient(string ingredientName, double quantity, string unit)
        {
            Ingredients ingredient = new Ingredients
            {
                Name = ingredientName,
                Quantity = quantity,
                Unit = unit
            };
            ingredientList.Add(ingredient);
        }

        // Method to add a step to the recipe
        internal void AddStep(string stepDescription)
        {
            stepsList.Add(stepDescription);
        }

        // Method to print the recipe details
        internal void PrintRecipe()
        {
            Console.WriteLine("Recipe Name: " + Name);
            Console.WriteLine("\nIngredients:");
            foreach (var ingredient in ingredientList)
            {
                Console.WriteLine("- " + ingredient.Quantity + " " + ingredient.Unit + " " + ingredient.Name);
            }
            Console.WriteLine("\nSteps:");
            foreach (var step in stepsList)
            {
                Console.WriteLine("- " + step);
            }
        }

        // Method to scale ingredient quantities
        internal void ScaleIngredients(double factor)
        {
            foreach (var ingredient in ingredientList)
            {
                ingredient.Quantity *= factor;
            }
        }

        // Method to reset ingredient quantities to original values
        internal void ResetQuantities()
        {
            // No need to do anything here as quantities are stored directly
            // Original values will be retained
        }
    }
}
